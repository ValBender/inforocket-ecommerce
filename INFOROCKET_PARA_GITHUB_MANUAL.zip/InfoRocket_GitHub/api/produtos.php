<?php
require 'db.php';
require 'auth.php';

session_start();

// Verificar se o usuário está logado e é admin
if (!isset($_SESSION["user"]) || !isAdmin()) {
    http_response_code(403);
    echo json_encode(['error' => 'Acesso negado']);
    exit();
}

header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            getProduto($_GET['id']);
        } else {
            getAllProdutos();
        }
        break;
    
    case 'POST':
        createProduto();
        break;
    
    case 'PUT':
        updateProduto();
        break;
    
    case 'DELETE':
        if (isset($_GET['id'])) {
            deleteProduto($_GET['id']);
        } else {
            http_response_code(400);
            echo json_encode(['error' => 'ID do produto é obrigatório']);
        }
        break;
    
    default:
        http_response_code(405);
        echo json_encode(['error' => 'Método não permitido']);
        break;
}

/**
 * Obter todos os produtos
 */
function getAllProdutos() {
    global $con;
    
    $sql = "SELECT id, nome, descricao, preco, created_at, updated_at FROM Produto ORDER BY created_at DESC";
    $result = $con->query($sql);
    
    $produtos = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $produtos[] = $row;
        }
    }
    
    echo json_encode($produtos);
}

/**
 * Obter um produto específico
 */
function getProduto($id) {
    global $con;
    
    $sql = $con->prepare("SELECT id, nome, descricao, preco, created_at, updated_at FROM Produto WHERE id = ?");
    $sql->bind_param('i', $id);
    $sql->execute();
    $result = $sql->get_result();
    
    if ($result->num_rows > 0) {
        $produto = $result->fetch_assoc();
        echo json_encode($produto);
    } else {
        http_response_code(404);
        echo json_encode(['error' => 'Produto não encontrado']);
    }
}

/**
 * Criar um novo produto
 */
function createProduto() {
    global $con;
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($input['nome']) || !isset($input['descricao']) || !isset($input['preco'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Nome, descrição e preço são obrigatórios']);
        return;
    }
    
    $nome = $input['nome'];
    $descricao = $input['descricao'];
    $preco = $input['preco'];
    $imagem = isset($input['imagem']) ? $input['imagem'] : null;
    
    if ($imagem) {
        $sql = $con->prepare("INSERT INTO Produto (nome, descricao, preco, imagem) VALUES (?, ?, ?, ?)");
        $sql->bind_param('ssds', $nome, $descricao, $preco, $imagem);
    } else {
        $sql = $con->prepare("INSERT INTO Produto (nome, descricao, preco) VALUES (?, ?, ?)");
        $sql->bind_param('ssd', $nome, $descricao, $preco);
    }
    
    if ($sql->execute()) {
        $id = $con->insert_id;
        echo json_encode(['success' => true, 'id' => $id, 'message' => 'Produto criado com sucesso']);
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'Erro ao criar produto']);
    }
}

/**
 * Atualizar um produto
 */
function updateProduto() {
    global $con;
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($input['id']) || !isset($input['nome']) || !isset($input['descricao']) || !isset($input['preco'])) {
        http_response_code(400);
        echo json_encode(['error' => 'ID, nome, descrição e preço são obrigatórios']);
        return;
    }
    
    $id = $input['id'];
    $nome = $input['nome'];
    $descricao = $input['descricao'];
    $preco = $input['preco'];
    $imagem = isset($input['imagem']) ? $input['imagem'] : null;
    
    if ($imagem) {
        $sql = $con->prepare("UPDATE Produto SET nome = ?, descricao = ?, preco = ?, imagem = ? WHERE id = ?");
        $sql->bind_param('ssdsi', $nome, $descricao, $preco, $imagem, $id);
    } else {
        $sql = $con->prepare("UPDATE Produto SET nome = ?, descricao = ?, preco = ? WHERE id = ?");
        $sql->bind_param('ssdi', $nome, $descricao, $preco, $id);
    }
    
    if ($sql->execute()) {
        if ($sql->affected_rows > 0) {
            echo json_encode(['success' => true, 'message' => 'Produto atualizado com sucesso']);
        } else {
            http_response_code(404);
            echo json_encode(['error' => 'Produto não encontrado']);
        }
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'Erro ao atualizar produto']);
    }
}

/**
 * Eliminar um produto
 */
function deleteProduto($id) {
    global $con;
    
    $sql = $con->prepare("DELETE FROM Produto WHERE id = ?");
    $sql->bind_param('i', $id);
    
    if ($sql->execute()) {
        if ($sql->affected_rows > 0) {
            echo json_encode(['success' => true, 'message' => 'Produto eliminado com sucesso']);
        } else {
            http_response_code(404);
            echo json_encode(['error' => 'Produto não encontrado']);
        }
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'Erro ao eliminar produto']);
    }
}
?>

