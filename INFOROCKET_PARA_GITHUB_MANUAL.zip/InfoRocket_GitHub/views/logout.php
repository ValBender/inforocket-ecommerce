<?php
    header("Location: login.php");
    session_destroy();
    exit();
?>